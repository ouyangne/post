import json
import re
import traceback

import jsonpath
import requests as requests
from common.tool import Tool
from common.foo import Foo
from common.logtool import LogTool, write_log, error_log


class RequestTool:
    #处理请求：检查数据、替换数据
    def request(self,caseinfo):
        try:
            if caseinfo == "":
                return 0
            new_caseinfo = self.process_info(caseinfo)
            #处理request参数
            url = new_caseinfo["request"]["url"]
            method = str(new_caseinfo["request"]["method"]).lower()
            del new_caseinfo["request"]["url"]
            del new_caseinfo["request"]["method"]
            # print(new_caseinfo)
            #处理file
            new_file = None
            path = None
            if "file" in new_caseinfo["request"].keys():
                #对file路径进行处理，打开文件
                path =  new_caseinfo["request"]["file"]
                for k,v in new_caseinfo["request"]["file"].items():
                    new_file = {k:v}
                    with open(path,encoding="utf-8",mode="rb") as f:
                        file = f.read()
                        new_file[k] = file
                        del new_caseinfo["request"]["file"]
            #替换参数中的方法
            for k,v in new_caseinfo["request"].items():
                v = self.process_requestdata(v)
                new_caseinfo["request"][k] = v

            # print(new_caseinfo["request"])
            res = self.send_request(method=method, url=url, files=new_file, **new_caseinfo["request"])
            # if "variable" in new_caseinfo.keys() and new_caseinfo["variable"] != None:
            #     self.process_variable(res,new_caseinfo["variable"])

            #把之前删除的加回来
            new_caseinfo["request"]["url"] = url
            new_caseinfo["request"]["method"] = method
            if new_file != None:
                new_caseinfo["request"]["file"] = path
            # print(new_caseinfo)
            Tool().process_allure(caseinfo=new_caseinfo,res=res)
            #断言
            self.assert_res(res,new_caseinfo["assertoption"])
            #提取变量
            if "variable" in new_caseinfo.keys() and new_caseinfo["variable"] != None:
                 self.process_variable(res,new_caseinfo["variable"])


            return res
        except Exception as e:
            error_log("处理请求报错信息：%s"%str(traceback.format_exc()))


    #中间变量
    def process_variable(self,res,key):
        try:
            if isinstance(key,dict):
                newkey = []
                for k,v in key.items():
                    newkey.append({k:v})
                key = newkey
            for i in range(0,len(key)):
                for k,v in key[i].items():
                    if '"' in v:
                    #采用正则
                        data = res.text
                        s = re.findall(v, data)
                        if s != []:
                            r = {k:s[0]}
                            # print(r)
                            Tool().write_global(r)
                            write_log("写入变量 "+k+" :"+str(s[0]))
                        else:
                            error_log("-------------variable关键字写入变量时在" + data + "中找不到" + v + "----------------")
                    else:
                        #jsonpath
                        s = jsonpath.jsonpath(res.json(),v)
                        if s != False:
                            # print(s)
                            r = {k: s[0]}
                            # print(r)
                            Tool().write_global(r)
                            write_log("写入变量 " + k + " :" + str(s[0]))
                        else:
                            error_log("-------------variable关键字写入变量时在"+str(res.json().keys())+"中找不到"+v+"----------------")
        except Exception as e:
            error_log("提取中间变量报错信息：%s"%str(traceback.format_exc()))
    #实际发送请求
    def send_request(self,method,url,files=None,**kwargs):
        #print(kwargs)  #{'params': {'key': 'global16657305458764'}, 'json': {'a': '1'}, 'headers': {'Content-Type': 'application/x-www-form-urlencoded'}}
        try:
            write_log("--------------------发送请求---------------------")
            write_log("请求路径：%s"%url)
            write_log("请求方式：%s"%method)
            new_kwargs = {}
            #如果是json传参，需要转换参数成json格式
            for k,v in kwargs.items():
                if k == "json":
                    new_kwargs["data"] = json.dumps(v) #{"a": "1"}
                else:
                    new_kwargs[k] = v
            #打印日志，因为需要转换格式成字符串
            for k, v in new_kwargs.items():
                print(v)
                # print(type(v))
                # print(v)
                if v == None:
                    v = "None"
                if isinstance(v,dict):
                    v = json.dumps(v)
                write_log("请求数据 "+str(k)+":"+v)

            session = requests.session()
            res = session.request(method=method,url=url,files=files,verify=False,**new_kwargs)
            write_log("响应状态码:%s"%str(res.status_code))
            write_log("响应数据:%s"%str(res.text))
            return res
        except Exception as e:
            error_log("发送请求报错信息：%s"%str(traceback.format_exc()))
    #断言
    # new_caseinfo["assertoption"]
    def assert_res(self,res,assert_options):
        try:
            write_log("断言内容%s"%str(assert_options))
            if isinstance(assert_options,list):
                for i in range(0,len(assert_options)):
                    options = assert_options[i]
                    # print(options)
                    for k,v in options.items():
                        if k == "eq" or k == "contains":
                            if k == "eq":
                            # print(v)
                            # print("--------------")
                            # print(res.status_code)
                                for st,code in v.items():
                                    assert str(v[st]) == str(res.status_code)
                                    # write_log("断言失败：%s"%str(traceback.format_exc()))
                            if k == "contains":
                                assert str(res.text).find(options[k]) !=-1
                                # write_log("断言失败：%s"%str(traceback.format_exc()))

                        else:
                            write_log("------------不支持"+str(k)+"断言--------------")
                write_log("-----------------------断言成功------------------------")
                write_log("-----------------------请求完成-------------------------")
        except Exception as e:
            error_log("处理断言报错信息：%s"%str(traceback.format_exc()))


    #处理yml请求数据：{{全局变量}}
    def process_info(self,data):
        try:
            # data = str(data)
            data = json.dumps(data,ensure_ascii=False)
            while "{{" in data:
                l = data.find("{{")
                r = data.find("}}")
                old = data[l:r + 2]
                oldkey = data[l + 2:r]
                # print(oldkey)
                # print(old)
                new = str(Tool().read_global(oldkey))
                data = data.replace(old, new)
            # newdata = ast.literal_eval(data)
            newdata = json.loads(data)
            ensure_ascii = False
            return newdata
        except Exception as e:
            error_log("处理全局变量报错信息：%s"%str(traceback.format_exc()))
#参数的方法
    def process_requestdata(self,data):
        try:
            # data = str(data)
            data = json.dumps(data,ensure_ascii=False)
            while "${" in data and "}$" in data:
                l = data.find("${")
                r = data.find("}$")
                old = data[l:r + 2]
                oldkey = data[l + 2:r]
                l2 = oldkey.find("(")
                oldname = oldkey[0:l2]
                cs = oldkey[l2 + 1:-1]
            # print(old)
            # print(oldname)
            # print(cs)
                new = ""
                if hasattr(Foo(), oldname):
                    new = getattr(Foo(), oldname)(cs)
                data = data.replace(old,new)
            # newdata = ast.literal_eval(data)
            newdata = json.loads(data)
            # print(newdata)
            return newdata
        except Exception as e:
            error_log("处理requestdata报错信息：%s"%str(traceback.format_exc()))

#读取yml文件，对文件格式做判断必须包含url、request-method、assert、，读取csv文件处理数据值，创造多组数据，
# 通过mark数据驱动，对数据的值{{}}，${}反射替换，读取参数，发送请求
if __name__ == '__main__':
    # url = "http://127.0.0.1:8888/index"
    # data = {"username":"tretret"}
    # res = requests.session().request(url=url,method="get")
    # print(res.text)


    # url = "https://192.168.18.81/api/auth/login"
    # data = {"password": "SoxFJKupKF9QDQVTBuq3GyJQMbXESKeIQbZHODLdyflJGPKofH/H5Am35aG22dBr695iP5HitaK236Ua5QA/QIZolz8fhuVQ72mT6KnS2/SRYyyNFiv8F9jPU1LJweblAkPARSCcX5VxCb/2RRg0N56FlLXz9D+VbhyQhM8M41A=","username": "admin"}
    # data = json.dumps(data)
    # header = {"Content-Type":"application/json"}
    # res = requests.session().request(url=url, method="post",data=data,verify=False,headers=header)
    # print(res.text)

    headers= {"Content-Type": "multipart/form-data; boundary=----WebKitFormBoundaryeKKxL1R1PBgAAPJQ",
              "Authorization": "Bearer eyJhbGciOiJIUzUxMiJ9.eyJsb2dpbl91c2VyX2tleSI6IjMxZDdjNzFjLTI2Y2ItNDI0Yi04ZTI3LWE4MjEwYmNhYWQ4NCJ9.XUooY9zxQfSVK1tjQ8fboqaQ_GhDk-vvRpoUqEbwu_SKdSR3AikGdc_sLbhpvL_pTUSKorWPhFixzk_q1PR8ZQ"}

    url = "https://192.168.18.81/api/workCenter/project/add"
    # with open("./bitter.pcap", mode="rb") as f:
    #     file = f
    files = [('files', ('./bitter.pcap', open('./bitter.pcap', 'rb')))]
    # Tuple[str, Tuple[str, BinaryIO, str]]

    data1 = {'sourceType': '2', 'projectType': '1,2,3', 'projectName': 'tfrhrt549199', 'province':'北京市', 'city':'市辖区'}
    res = requests.session().request(url=url, method="post", data=data1,files=files,verify=False, headers=headers)
    print(res.text)

    # url = "https://192.168.18.81/api/workCenter/project/add"
    #
    # payload = {'sourceType': '2',
    #            'projectType': '1,2,3',
    #            'projectName': 'fdfdf',
    #            'province': '北京市',
    #            'city': '市辖区'}
    # files = [
    #     ('files', ('蚁剑流量.pcapng', open('/E:/项目/ntt/pcap/流量/【4】web攻击/蚁剑流量.pcapng', 'rb'), 'application/octet-stream'))
    # ]
    # headers = {
    #     'Content-Type': 'application/json',
    #     'Authorization': 'Bearer Bearer eyJhbGciOiJIUzUxMiJ9.eyJsb2dpbl91c2VyX2tleSI6Ijc3ZmU3MjgzLWRlYzEtNDkwMS1iN2IxLTdlZWU0YWRjMmUzYyJ9.fpLouvkLATbaCLMl-h8-c_YqRAI9VUxPquOoMoaeeAQ0PfUqj4cBdHRCbOD7B5q82nne5xQYYSXcpZMYzUWcBg'
    # }
    #
    # response = requests.request("POST", url, headers=headers, data=payload, files=files)
    #
    # print(response.text)