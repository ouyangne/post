import csv
import json
import os
import traceback

import allure
import jsonpath
import yaml

from common.logtool import error_log, write_log


class Tool:
    def process_allure(self,caseinfo,res):
        try:
            if "descript" in caseinfo.keys():
                allure.dynamic.description(caseinfo["descript"])
            allure.attach(body=caseinfo["request"]["url"], name="请求地址", attachment_type=allure.attachment_type.TEXT)
            allure.attach(body=caseinfo["request"]["method"], name="请求方式", attachment_type=allure.attachment_type.TEXT)
            del caseinfo["request"]["url"]
            del caseinfo["request"]["method"]
            # ast.literal_eval(caseinfo)
            for k, v in caseinfo["request"].items():
                allure.attach(body=str(v), name=k, attachment_type=allure.attachment_type.TEXT)
            allure.attach(body=res.text, name="响应数据", attachment_type=allure.attachment_type.TEXT)
            allure.attach(body=str(caseinfo["assertoption"]), name="断言数据", attachment_type=allure.attachment_type.TEXT)
        except Exception as e:
            error_log("处理allure内容报错信息：%s"%str(traceback.format_exc()))

    #处理多组csv数据
    def process_caseinfo(self,yamlpath):
        try:
            write_log("---------------------提取yml请求数据---------------------")
            initial_caseinfo = self.read_yml(yamlpath)
            if self.check_date(initial_caseinfo) == False:
                write_log("---------------------请检查yml数据格式---------------------")
                return [""]
            if isinstance(initial_caseinfo,list):
                initial_caseinfo[0]["request"]["url"] = self.read_environment("url") + initial_caseinfo[0]["request"]["url"]
                caseinfo = initial_caseinfo[0]
                # 处理环境url
            if len(initial_caseinfo) == 1 and "csvdata" in caseinfo.keys():
                #处理：判断csv读取的每一行长度跟第一行是不是一致的，csv的头去对比中是否存在，
                # 存在就替换（转化成字符串，根据$变量名识别），替换后加入list，得到多组数据
                csvpath = str(yamlpath).split(".yml")[0]+".csv"
                csvdata = self.read_csv(csvpath)
                if csvdata == None:
                    return [caseinfo]
                caseinfolist = self.process_csv(caseinfo,csvdata)
                return caseinfolist
            return initial_caseinfo
        except Exception as e:
            error_log("处理yml文件报错信息：%s"%str(traceback.format_exc()))
    #csv替换yml
    def process_csv(self,caseinfo,csvdata):
        try:
            if csvdata == []:
                return caseinfo
            csvlist = str(caseinfo["csvdata"]).split("-")
            caseinfolist = []
            for i in range(1, len(csvdata)):
                new_caseinfo = caseinfo
                for j in range(0, len(csvdata[0])):
                    if csvdata[0][j] in csvlist:
                        old = "$" + csvdata[0][j]
                        new = csvdata[i][j]
                        if new == "None" or new == "True" or new == "False":
                            old = '"' + old + '"'
                            new = "null"
                        new = new.replace("-",",")
                        newdata = json.dumps(new_caseinfo,ensure_ascii=False).replace(old,new)
                        new_caseinfo = json.loads(newdata)
                caseinfolist.append(new_caseinfo)
            return caseinfolist
        except Exception as e:
            error_log("处理csv数据报错信息：%s"%str(traceback.format_exc()))

    #检查数据格式
    def check_date(self,caseinfo):
        try:
            # caseinfo = caseinfo[0]
            for i in range(0,len(caseinfo)):
                caseinfo = caseinfo[i]
                if "name" in caseinfo.keys() and "request" in caseinfo.keys() and "assertoption" in caseinfo.keys():
                    request_keys = caseinfo["request"].keys()
                    if "url" in request_keys and "method" in request_keys:
                        return True
                write_log("---------------------yml文件不符合格式要求：必须包含关键字name、request（url、method）、assertoption---------------------")
                return False
        except Exception as e:
            error_log("检查yml数据格式报错信息：%s"%str(traceback.format_exc()))
    # 读取yml文件
    def read_yml(self, path):
        try:
            with open(os.getcwd()+path,encoding="utf-8",mode='r') as f:
                value = yaml.load(stream=f,Loader=yaml.FullLoader)
                return value
        except Exception as e:
            error_log("读取yml文件报错信息：%s"%str(traceback.format_exc()))

    # 读取csv文件
    def read_csv(self, path):
        try:
            with open(os.getcwd()+path,encoding="utf-8",mode="r") as f:
                value = csv.reader(f)
                list = []
                for row in value:
                    list.append(row)
                if len(list) > 0:
                    length = len(list[0])
                    for i in range(1,len(list)):
                        if len(list[i]) != length:
                            write_log("---------------------csv文件参数格式错误：检查每一行的长度---------------------")
                            return None
                return list
        except Exception as e:
            error_log("读取csv文件报错信息：%s"%str(traceback.format_exc()))


    #清除所有中间变量
    def clear_global(self):
        try:
            with open(os.getcwd()+"/global_variable.yml",mode="w") as f:
                f.truncate()
        except Exception as e:
            error_log("清楚中间变量报错信息：%s"%str(traceback.format_exc()))

    #读取中间变量
    def read_global(self,key):
        try:
            with open(os.getcwd() + "/global_variable.yml", mode="r") as f:
                value = yaml.load(stream=f,Loader=yaml.FullLoader)
                if value:
                    keylist = value.keys()
                    if key in keylist:
                        return value[key]
                    else:
                        write_log("---------------------需要的中间变量%s不存在---------------------".format(key))
                else:
                    write_log("---------------------global variable文件为空---------------------")
                return key
        except Exception as e:
            error_log("读取中间变量报错信息：%s"%str(traceback.format_exc()))
    #写入中间变量
    def write_global(self,data):
        try:
            with open(os.getcwd() + "/global_variable.yml", mode="a") as f:
                # for key,value in data.items:
                yaml.dump(data,f)
        except Exception as e:
            error_log("写入中间变量报错信息：%s"%str(traceback.format_exc()))


    #读取环境变量
    def read_environment(self,key):
        try:
            with open(os.getcwd() + "/environment.yml", mode="r") as f:
                value = yaml.load(stream=f,Loader=yaml.FullLoader)
                if key in value.keys():
                    return value[key]
                return 0
        except Exception as e:
            error_log("读取环境变量报错信息：%s"%str(traceback.format_exc()))

    #删除文件夹下所有文件
    def del_files(self,dir_path):
        try:
            # os.walk会得到dir_path下各个后代文件夹和其中的文件的三元组列表，顺序自内而外排列，
            # 如 log下有111文件夹，111下有222文件夹：[('D:\\log\\111\\222', [], ['22.py']), ('D:\\log\\111', ['222'], ['11.py']), ('D:\\log', ['111'], ['00.py'])]
            for root, dirs, files in os.walk(dir_path, topdown=False):
                # print(root)  # 各级文件夹绝对路径
                # print(dirs)  # root下一级文件夹名称列表，如 ['文件夹1','文件夹2']
                # print(files)  # root下文件名列表，如 ['文件1','文件2']
                # 第一步：删除文件
                for name in files:
                    os.remove(os.path.join(root, name))  # 删除文件
                # 第二步：删除空文件夹
                for name in dirs:
                    os.rmdir(os.path.join(root, name))
        except Exception as e:
            error_log("删除文件夹报错信息：%s"%str(traceback.format_exc()))


if __name__ == '__main__':
    data = {"name": "正向用例", "descript": "$descript", "csvdata": "name-method-params-status_code-contains-descript",
     "request": {"url": "http://v.juhe.cn/dream/category", "method": "$method", "params": "$params",
                 "headers": {"Content-Type": "application/x-www-form-urlencoded"}},
     "variable": [{"resultcode": "resultcode\":\"(.*?)\","}],
     "assertoption": [{"eq": {"status_code": "$status_code"}}, {"contains": "$contains"}]}
