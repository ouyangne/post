import random
import time

#反射函数类
class Foo:

    #通过时间＋随机数方式生成字符串，6-14位长度
    def random_str(self,length):
        #生成字符串5-14位长度
        if isinstance(length,str):
            length = int(length)
        # print(key)
        if length > 14:
            length = 14
        if length < 6:
            length = 6
        num = str(random.randint(1000,9999))
        timenow = str(time.time())[10-(length-4):10]
        # print(num+timenow)
        return timenow+num


# print(time.time())
# print(int(str(time.time())[10:10]))
# print(random.randint(1000,9999))
if __name__ == '__main__':
    print(Foo().random_str(6))

