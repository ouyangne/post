import logging
import os


class LogTool:

    def create_log(self,logger_name="log"):
        #创建一个日志对象
        logger = logging.getLogger(logger_name)
        #设置全局的日志级别
        logger.setLevel(logging.DEBUG)
        # print(logger)
        if not logger.handlers:
            #日志文件控制器
            file_path = os.getcwd()+"/log/log.log"
            hand = logging.FileHandler(file_path,encoding="utf-8")
            hand.setLevel(logging.DEBUG)
            #控制台控制器
            hand_console = logging.StreamHandler()
            hand_console.setLevel(logging.DEBUG)
            #输出格式
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            hand.setFormatter(formatter)
            hand_console.setFormatter(formatter)

            logger.addHandler(hand)
            logger.addHandler(hand_console)
        return logger

def write_log(write):
    LogTool().create_log().info(write)

def error_log(write):
    LogTool().create_log().info(write)
    raise Exception(write)