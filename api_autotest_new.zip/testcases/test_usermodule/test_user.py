import allure
import pytest
from common.tool import Tool
from common.requesttool import RequestTool

@allure.epic("流量产品项目")
@allure.feature("登录模块")
class TestUser:
    @pytest.mark.run('first')
    @allure.story("登录接口")
    @allure.title("用例:{caseinfo[name]}")
    # @allure.step("用例:{caseinfo[name]}")
    # @allure.link(name="接口地址",url="caseinfo[request][url]")
    @pytest.mark.parametrize("caseinfo",Tool().process_caseinfo("/data/user_module/login.yml"))
    def test_login(self,caseinfo):
        RequestTool().request(caseinfo=caseinfo)

# @allure.epic("流量产品项目")
# @allure.feature("登录模块")
# class Test2:
#     @allure.story("查看工程列表接口")
#     @allure.title("用例:{caseinfo[name]}")
#     # @allure.step("用例:{caseinfo[name]}")
#     # @allure.link(name="接口地址",url="caseinfo[request][url]")
#     @pytest.mark.parametrize("caseinfo",Tool().process_caseinfo("/data/project_module/get_prolist.yml"))
#     def test_02(self,caseinfo):
#         RequestTool().request(caseinfo=caseinfo)