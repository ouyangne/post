import allure
import pytest
from common.tool import Tool
from common.requesttool import RequestTool

@allure.epic("流量产品项目")
@allure.feature("公共模块")
class TestCommon:
    @allure.story("获取公钥接口")
    @allure.title("用例:{caseinfo[name]}")
    # @allure.step("用例:{caseinfo[name]}")
    # @allure.link(name="接口地址",url="caseinfo[request][url]")
    @pytest.mark.parametrize("caseinfo",Tool().process_caseinfo("/data/common_module/get_key.yml"))
    def test_getkey(self,caseinfo):
        RequestTool().request(caseinfo=caseinfo)