import allure
import pytest
from common.tool import Tool
from common.requesttool import RequestTool

@allure.epic("流量产品项目")
@allure.feature("工程模块")
class TestProject:
    @allure.story("查看工程列表接口")
    @allure.title("用例:{caseinfo[name]}")
    # @allure.step("用例:{caseinfo[name]}")
    # @allure.link(name="接口地址",url="caseinfo[request][url]")
    @pytest.mark.parametrize("caseinfo",Tool().process_caseinfo("/data/project_module/get_prolist.yml"))
    def test_01_getprolist(self,caseinfo):
        RequestTool().request(caseinfo=caseinfo)

    # @allure.story("创建工程接口")
    # @allure.title("用例:{caseinfo[name]}")
    # # @allure.step("用例:{caseinfo[name]}")
    # # @allure.link(name="接口地址",url="caseinfo[request][url]")
    # @pytest.mark.parametrize("caseinfo", Tool().process_caseinfo("/data/project_module/creat_project.yml"))
    # def test_02_getprolist(self, caseinfo):
    #     RequestTool().request(caseinfo=caseinfo)


    @allure.story("查看工程态势总览接口")
    @allure.title("用例:{caseinfo[name]}")
    # @allure.step("用例:{caseinfo[name]}")
    # @allure.link(name="接口地址",url="caseinfo[request][url]")
    @pytest.mark.parametrize("caseinfo", Tool().process_caseinfo("/data/project_module/get_countlist.yml"))
    def test_03_getcountlist(self, caseinfo):
        RequestTool().request(caseinfo=caseinfo)



    @allure.story("查看tcp接口")
    @allure.title("用例:{caseinfo[name]}")
    # @allure.step("用例:{caseinfo[name]}")
    # @allure.link(name="接口地址",url="caseinfo[request][url]")
    @pytest.mark.parametrize("caseinfo", Tool().process_caseinfo("/data/project_module/get_tcpflows.yml"))
    def test_04_gettcplist(self, caseinfo):
        RequestTool().request(caseinfo=caseinfo)