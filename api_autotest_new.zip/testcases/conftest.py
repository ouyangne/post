import sys
import os
sys.path.append(os.path.split(os.path.abspath(os.path.dirname(__file__)))[0])
import pytest
from common.tool import Tool
from common.logtool import write_log
@pytest.fixture(scope="session",autouse=True)
def session_set():
    print("")
    write_log("----------------------清空全局变量----------------------")
    Tool().clear_global()
    write_log("----------------------清空临时报告文件-------------------")
    Tool().del_files("./temps")
    yield
    write_log("-------------------------测试结束-------------------------")
