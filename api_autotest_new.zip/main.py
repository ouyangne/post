import csv
import json
import os
import pytest
import pandas
import yaml

from common.tool import Tool
if __name__ == '__main__':
    # pytest.main(["-s","./testcases/test_commonmodule/test1.py","--alluredir=temps"])
    pytest.main()
    os.system("allure generate ./temps -o ./reports --clean")
    # data = {"dsd":None,"dwdwd":"null"}
    # data1 = json.dumps(data)
    # print(data)
    # print(data1)
    # data2 = str(data)
    # print(data2)
    # data4 = json.loads(data1)
    # print(data4)
    # str1 = "123"
    # print(str1.find(","))
    # print(str1.replace("-",","))
    # print(str1)